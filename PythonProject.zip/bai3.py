kw = int(input("Nhập số KW tiêu thụ: "))

tien_dien =0
if kw <= 100:
    tien_dien = kw * 450
elif kw <= 200:
    tien_dien = 100 * 450 + (kw - 100) * 600
elif kw <= 300:
    tien_dien = 100 * 450 + 100 * 600 + (kw - 200) * 750
elif kw <= 500:
    tien_dien = 100 * 450 + 100 * 600 + 100 * 750 + (kw - 300) * 900
elif kw <= 1000:
    tien_dien = 100 * 450 + 100 * 600 + 100 * 750 + 200 * 900 + (kw - 500) * 1000
else:
    tien_dien = 100 * 450 + 100 * 600 + 100 * 750 + 200 * 900 + 500 * 1000 + (kw - 1000) * 1200

thue_vat = tien_dien * 0.10
tong_tien = tien_dien + thue_vat

print(f"\nSố KW tiêu thụ: {kw} KW")
print(f"Tiền điện trước thuế: {tien_dien:,} đồng")
print(f"Thuế VAT (10%): {thue_vat:,} đồng")
print(f"Tổng tiền phải trả: {tong_tien:,} đồng")